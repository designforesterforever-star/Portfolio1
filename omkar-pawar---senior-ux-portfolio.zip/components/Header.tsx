import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { NavItem } from '../types';

interface HeaderProps {
  navItems: NavItem[];
  logoUrl?: string;
  showLogo: boolean;
  showNav: boolean;
}

const Header: React.FC<HeaderProps> = ({ navItems, logoUrl, showLogo, showNav }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b-4 border-black bg-white">
      <div className="flex items-center justify-between p-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
            {showLogo && (
                logoUrl ? (
                    <img src={logoUrl} alt="Logo" className="w-8 h-8 rounded-full animate-bounce object-cover border border-black" />
                ) : (
                    <div className="w-8 h-8 bg-black rounded-full animate-bounce"></div>
                )
            )}
            <h1 className="text-2xl font-black tracking-tighter uppercase select-none hover:text-deep-purple transition-colors">
            Omkar<span className="text-hot-pink">.Pawar</span>
            </h1>
        </div>

        {/* Desktop Nav */}
        {showNav && (
            <>
                <nav className="hidden md:flex gap-8">
                {navItems.map((item) => (
                    <a
                    key={item.label}
                    href={item.href}
                    className="text-lg font-bold border-b-2 border-transparent hover:border-black hover:-translate-y-1 transition-all duration-200"
                    >
                    {item.label}
                    </a>
                ))}
                </nav>

                {/* Mobile Toggle */}
                <button
                className="md:hidden p-2 border-2 border-black shadow-hard-sm active:translate-y-1 active:shadow-none transition-all"
                onClick={() => setIsOpen(!isOpen)}
                aria-label="Toggle menu"
                >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </>
        )}
      </div>

      {/* Mobile Nav */}
      {showNav && isOpen && (
        <nav className="md:hidden bg-acid-green border-t-4 border-black p-4 flex flex-col gap-4">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={() => setIsOpen(false)}
              className="text-2xl font-black hover:underline decoration-wavy decoration-2"
            >
              {item.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
};

export default Header;