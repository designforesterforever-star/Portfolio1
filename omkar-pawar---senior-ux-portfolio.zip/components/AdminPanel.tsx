import React, { useState, useRef } from 'react';
import { X, Upload, Plus, Trash2, Save, FileType, Loader, Globe, Lock, Key, ShieldCheck, Mail, AlertTriangle, Camera, Eye, EyeOff } from 'lucide-react';
import { SiteContent, NavItem, SocialLink, Project } from '../types';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  content: SiteContent;
  onUpdate: (newContent: SiteContent) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose, content, onUpdate }) => {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('Omkarpassp123@');
  const [authView, setAuthView] = useState<'login' | 'reset'>('login');
  const [loginInput, setLoginInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // OTP / Reset State
  const [resetStep, setResetStep] = useState<'request' | 'verify'>('request');
  const [otp, setOtp] = useState('');
  const [otpInput, setOtpInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [resetError, setResetError] = useState('');

  // CMS State
  const [activeTab, setActiveTab] = useState<'general' | 'sections' | 'security'>('general');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [localContent, setLocalContent] = useState<SiteContent>(content);

  if (!isOpen) return null;

  // --- Auth Handlers ---

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginInput === currentPassword) {
      setIsAuthenticated(true);
      setLoginError('');
      setLoginInput('');
    } else {
      setLoginError('ACCESS DENIED: Incorrect Password');
    }
  };

  const handleSendOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setOtp(code);
    setResetStep('verify');
    // Simulation of email service
    alert(`[SIMULATION] Email sent to omipawar17@gmail.com\n\nYour OTP is: ${code}`);
  };

  const handleVerifyAndReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpInput === otp) {
      setCurrentPassword(newPasswordInput);
      setIsAuthenticated(true); // Auto login after reset
      setAuthView('login'); // Reset view state
      setResetStep('request');
      setOtpInput('');
      setNewPasswordInput('');
      setResetError('');
      alert("Password updated successfully.");
    } else {
      setResetError("INVALID OTP. IDENTITY UNVERIFIED.");
    }
  };

  // --- CMS Handlers ---

  const handleSave = () => {
    onUpdate(localContent);
    onClose();
  };

  const handleFigmaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    setTimeout(() => {
      const newProject: Project = {
        id: Date.now(),
        title: file.name.replace('.fig', '').split('-').join(' '),
        category: "Imported Design",
        description: "This section was automatically generated from the uploaded Figma design file. All constraints were parsed successfully.",
        imageUrl: `https://picsum.photos/600/400?random=${Date.now()}`,
        link: "#",
        bgColor: "bg-purple-200",
        figmaLink: "#"
      };

      setLocalContent(prev => ({
        ...prev,
        projects: [newProject, ...prev.projects]
      }));
      setIsUploading(false);
    }, 2500);
  };
  
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLocalContent(prev => ({
            ...prev,
            logoUrl: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const updateNavItem = (index: number, field: keyof NavItem, value: string) => {
    const newNav = [...localContent.navItems];
    newNav[index] = { ...newNav[index], [field]: value };
    setLocalContent({ ...localContent, navItems: newNav });
  };

  const addNavItem = () => {
    setLocalContent({
      ...localContent,
      navItems: [...localContent.navItems, { label: 'New Link', href: '#' }]
    });
  };

  const removeNavItem = (index: number) => {
    const newNav = localContent.navItems.filter((_, i) => i !== index);
    setLocalContent({ ...localContent, navItems: newNav });
  };

  const updateSocialLink = (index: number, field: keyof SocialLink, value: string) => {
    const newSocials = [...localContent.socialLinks];
    // @ts-ignore
    newSocials[index] = { ...newSocials[index], [field]: value };
    setLocalContent({ ...localContent, socialLinks: newSocials });
  };

  const addSocialLink = () => {
      setLocalContent({
          ...localContent,
          socialLinks: [...localContent.socialLinks, { platform: 'globe', url: '#' }]
      });
  };

  const removeSocialLink = (index: number) => {
      const newSocials = localContent.socialLinks.filter((_, i) => i !== index);
      setLocalContent({ ...localContent, socialLinks: newSocials });
  };


  // --- RENDER: LOGIN SCREEN ---
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-md border-4 border-black shadow-hard relative">
          <button onClick={onClose} className="absolute top-2 right-2 p-1 hover:bg-black hover:text-white transition-colors">
            <X size={24} />
          </button>
          
          <div className="p-8">
            <div className="flex justify-center mb-6">
              <div className="bg-black text-white p-4 rounded-full">
                <Lock size={32} />
              </div>
            </div>
            
            <h2 className="text-3xl font-black text-center mb-2 uppercase">Restricted Access</h2>
            <p className="text-center font-mono text-sm text-gray-600 mb-8">
              Authorized personnel only.
            </p>

            {authView === 'login' ? (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block font-bold text-xs uppercase tracking-wider mb-1">Password</label>
                  <input 
                    type="password"
                    value={loginInput}
                    onChange={(e) => setLoginInput(e.target.value)}
                    className="w-full border-2 border-black p-3 font-mono text-lg focus:outline-none focus:bg-yellow-100 transition-colors"
                    placeholder="Enter password..."
                    autoFocus
                  />
                </div>
                
                {loginError && (
                  <div className="bg-red-100 border-2 border-red-500 p-2 text-red-600 font-bold text-xs flex items-center gap-2">
                    <AlertTriangle size={14} /> {loginError}
                  </div>
                )}

                <button type="submit" className="w-full bg-black text-white p-4 font-bold uppercase hover:bg-acid-green hover:text-black border-2 border-transparent hover:border-black transition-all">
                  Unlock System
                </button>

                <div className="text-center pt-2">
                  <button 
                    type="button"
                    onClick={() => { setAuthView('reset'); setResetStep('request'); setLoginError(''); }}
                    className="text-xs font-bold text-gray-500 hover:text-black underline decoration-dotted"
                  >
                    Forgot Password?
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="bg-blue-50 border-2 border-blue-200 p-3 text-xs font-mono mb-4">
                  <div className="font-bold mb-1 flex items-center gap-1"><ShieldCheck size={12}/> IDENTITY VERIFICATION</div>
                  To reset your password, we must verify your identity via OTP sent to:
                  <div className="font-bold mt-1">omipawar17@gmail.com</div>
                </div>

                {resetStep === 'request' ? (
                  <button 
                    onClick={handleSendOtp}
                    className="w-full bg-blue-600 text-white p-4 font-bold uppercase hover:bg-blue-700 border-2 border-transparent transition-all flex items-center justify-center gap-2"
                  >
                    <Mail size={18} /> Send OTP
                  </button>
                ) : (
                  <form onSubmit={handleVerifyAndReset} className="space-y-4">
                     <div>
                      <label className="block font-bold text-xs uppercase tracking-wider mb-1">One-Time Password</label>
                      <input 
                        type="text"
                        value={otpInput}
                        onChange={(e) => setOtpInput(e.target.value)}
                        className="w-full border-2 border-black p-3 font-mono text-lg focus:outline-none focus:bg-yellow-100"
                        placeholder="######"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-xs uppercase tracking-wider mb-1">New Password</label>
                      <input 
                        type="password"
                        value={newPasswordInput}
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        className="w-full border-2 border-black p-3 font-mono text-lg focus:outline-none focus:bg-yellow-100"
                        placeholder="New secure password"
                      />
                    </div>

                    {resetError && (
                      <div className="bg-red-100 border-2 border-red-500 p-2 text-red-600 font-bold text-xs">
                        {resetError}
                      </div>
                    )}

                    <button type="submit" className="w-full bg-black text-white p-4 font-bold uppercase hover:bg-hot-pink hover:text-white border-2 border-transparent hover:border-black transition-all">
                      Verify & Change
                    </button>
                  </form>
                )}
                
                <div className="text-center pt-2">
                  <button 
                    onClick={() => setAuthView('login')}
                    className="text-xs font-bold text-gray-500 hover:text-black"
                  >
                    &larr; Back to Login
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --- RENDER: ADMIN PANEL (AUTHENTICATED) ---

  return (
    <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex justify-end">
      <div className="w-full md:w-[500px] bg-white h-full border-l-4 border-black shadow-2xl overflow-y-auto flex flex-col">
        {/* Header */}
        <div className="p-6 bg-acid-green border-b-4 border-black flex justify-between items-center sticky top-0 z-10">
          <h2 className="text-3xl font-black uppercase">CMS Backend</h2>
          <div className="flex items-center gap-2">
            <button onClick={() => setIsAuthenticated(false)} className="p-2 bg-white border-2 border-black hover:bg-red-500 hover:text-white transition-colors" title="Lock">
                <Lock size={20} />
            </button>
            <button onClick={onClose} className="p-2 bg-white border-2 border-black hover:bg-black hover:text-white transition-colors">
                <X size={20} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b-4 border-black overflow-x-auto">
          <button
            onClick={() => setActiveTab('general')}
            className={`flex-1 min-w-[100px] p-4 font-bold uppercase text-xs md:text-sm ${activeTab === 'general' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}
          >
            General
          </button>
          <button
            onClick={() => setActiveTab('sections')}
            className={`flex-1 min-w-[100px] p-4 font-bold uppercase text-xs md:text-sm ${activeTab === 'sections' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}
          >
            Figma/Sections
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`flex-1 min-w-[100px] p-4 font-bold uppercase text-xs md:text-sm ${activeTab === 'security' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}
          >
            Security
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex-grow space-y-8">
          
          {activeTab === 'general' && (
            <div className="space-y-8">
              
              <section className="border-b-2 border-dashed border-gray-300 pb-6">
                <h3 className="text-xl font-black mb-4 flex items-center gap-2"><Camera size={20} /> Logo Settings</h3>
                
                <div className="flex items-center justify-between mb-4 bg-gray-50 p-3 border-2 border-black">
                   <span className="font-bold font-mono text-sm">Show Logo (Circle)</span>
                   <button 
                      onClick={() => setLocalContent({...localContent, showLogo: !localContent.showLogo})}
                      className={`w-12 h-6 rounded-full border-2 border-black p-0.5 transition-colors ${localContent.showLogo !== false ? 'bg-hot-pink' : 'bg-gray-300'}`}
                   >
                      <div className={`w-4 h-4 bg-white rounded-full border-2 border-black transition-transform ${localContent.showLogo !== false ? 'translate-x-6' : 'translate-x-0'}`}></div>
                   </button>
                </div>

                <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full border-2 border-black overflow-hidden bg-gray-100 relative flex-shrink-0">
                        {localContent.logoUrl ? (
                            <img src={localContent.logoUrl} className="w-full h-full object-cover" alt="Preview" />
                        ) : (
                            <div className="w-full h-full bg-black animate-pulse"></div>
                        )}
                    </div>
                    <div className="flex flex-col gap-2">
                        <label className="cursor-pointer bg-black text-white px-4 py-2 font-bold uppercase text-xs hover:bg-hot-pink transition-colors border-2 border-transparent hover:border-black inline-flex items-center gap-2">
                            <Upload size={14} /> Upload Photo
                            <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                        </label>
                        {localContent.logoUrl && (
                            <button onClick={() => setLocalContent({...localContent, logoUrl: ''})} className="text-red-600 text-xs font-bold underline self-start">
                                Remove Logo
                            </button>
                        )}
                    </div>
                </div>
                <p className="text-xs text-gray-500 mt-2 font-mono">Appears in the top-left bouncing circle.</p>
              </section>

              <section>
                <h3 className="text-xl font-black mb-4 flex items-center gap-2">
                   Header Navigation
                </h3>
                
                <div className="flex items-center justify-between mb-4 bg-gray-50 p-3 border-2 border-black">
                   <span className="font-bold font-mono text-sm">Show Navigation Menu</span>
                   <button 
                      onClick={() => setLocalContent({...localContent, showNav: !localContent.showNav})}
                      className={`w-12 h-6 rounded-full border-2 border-black p-0.5 transition-colors ${localContent.showNav !== false ? 'bg-hot-pink' : 'bg-gray-300'}`}
                   >
                      <div className={`w-4 h-4 bg-white rounded-full border-2 border-black transition-transform ${localContent.showNav !== false ? 'translate-x-6' : 'translate-x-0'}`}></div>
                   </button>
                </div>

                <div className="space-y-3 opacity-90">
                  {localContent.navItems.map((item, idx) => (
                    <div key={idx} className="flex gap-2">
                      <input
                        value={item.label}
                        onChange={(e) => updateNavItem(idx, 'label', e.target.value)}
                        className="flex-1 border-2 border-black p-2 font-mono text-sm focus:outline-none focus:bg-yellow-100"
                        placeholder="Label"
                        disabled={localContent.showNav === false}
                      />
                      <input
                        value={item.href}
                        onChange={(e) => updateNavItem(idx, 'href', e.target.value)}
                        className="flex-1 border-2 border-black p-2 font-mono text-sm focus:outline-none focus:bg-yellow-100"
                        placeholder="URL"
                        disabled={localContent.showNav === false}
                      />
                      <button onClick={() => removeNavItem(idx)} className="p-2 bg-red-100 border-2 border-black hover:bg-red-500 hover:text-white">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                  <button onClick={addNavItem} className="w-full py-2 border-2 border-dashed border-black font-bold hover:bg-off-white flex items-center justify-center gap-2">
                    <Plus size={16} /> Add Menu Item
                  </button>
                </div>
              </section>

              <section>
                 <h3 className="text-xl font-black mb-4">Footer Email</h3>
                 <input 
                    value={localContent.email}
                    onChange={(e) => setLocalContent({...localContent, email: e.target.value})}
                    className="w-full border-2 border-black p-3 font-mono focus:outline-none focus:bg-yellow-100"
                 />
              </section>

              <section>
                <h3 className="text-xl font-black mb-4">Footer Socials</h3>
                <div className="space-y-3">
                    {localContent.socialLinks.map((link, idx) => (
                        <div key={idx} className="flex gap-2 items-start">
                             <select 
                                value={link.platform}
                                onChange={(e) => updateSocialLink(idx, 'platform', e.target.value)}
                                className="border-2 border-black p-2 font-mono text-sm h-10 bg-white"
                             >
                                <option value="linkedin">LinkedIn</option>
                                <option value="dribbble">Dribbble</option>
                                <option value="instagram">Instagram</option>
                                <option value="twitter">Twitter</option>
                                <option value="github">Github</option>
                                <option value="globe">Website</option>
                             </select>
                             <input 
                                value={link.url}
                                onChange={(e) => updateSocialLink(idx, 'url', e.target.value)}
                                className="flex-1 border-2 border-black p-2 font-mono text-sm h-10 focus:outline-none focus:bg-yellow-100"
                                placeholder="URL"
                             />
                             <button onClick={() => removeSocialLink(idx)} className="p-2 h-10 bg-red-100 border-2 border-black hover:bg-red-500 hover:text-white flex-shrink-0">
                                <Trash2 size={16} />
                            </button>
                        </div>
                    ))}
                     <button onClick={addSocialLink} className="w-full py-2 border-2 border-dashed border-black font-bold hover:bg-off-white flex items-center justify-center gap-2">
                        <Plus size={16} /> Add Social Link
                    </button>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'sections' && (
            <div className="space-y-8">
              {/* Figma Integration */}
              <div className="bg-off-white border-4 border-black p-6 relative overflow-hidden group">
                <div className="absolute top-2 right-2">
                   <div className="w-3 h-3 rounded-full bg-green-500 border border-black"></div>
                </div>
                <h3 className="text-xl font-black mb-2 flex items-center gap-2">
                  <FileType className="text-purple-600" /> Figma Import
                </h3>
                <p className="text-sm font-mono text-gray-600 mb-4">
                  Upload a .fig file to automatically generate a new section component.
                </p>
                
                {isUploading ? (
                  <div className="flex flex-col items-center justify-center py-8 space-y-4">
                    <Loader className="animate-spin text-hot-pink" size={32} />
                    <div className="font-mono text-xs font-bold animate-pulse">
                      PARSING VECTORS...
                    </div>
                  </div>
                ) : (
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-black bg-white p-8 flex flex-col items-center justify-center cursor-pointer hover:bg-purple-50 transition-colors"
                  >
                    <Upload size={32} className="mb-2" />
                    <span className="font-bold">Click to Upload Design</span>
                    <span className="text-xs text-gray-500 mt-1">Supports .fig (Max 50MB)</span>
                  </div>
                )}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept=".fig" 
                  onChange={handleFigmaUpload}
                />
              </div>

              {/* Current Sections List */}
              <div>
                <h3 className="text-xl font-black mb-4">Active Sections</h3>
                <div className="space-y-2">
                  {localContent.projects.map((project) => (
                    <div key={project.id} className="flex items-center gap-4 p-3 border-2 border-black bg-white">
                      <div className={`w-10 h-10 ${project.bgColor} border-2 border-black`}></div>
                      <div className="flex-grow">
                        <div className="font-bold text-sm">{project.title}</div>
                        <div className="text-xs font-mono text-gray-500">{project.category}</div>
                      </div>
                      <button 
                        onClick={() => {
                           const newProjs = localContent.projects.filter(p => p.id !== project.id);
                           setLocalContent({...localContent, projects: newProjs});
                        }}
                        className="text-red-500 hover:bg-red-100 p-2 rounded"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
             <div className="space-y-6">
                <div className="bg-yellow-50 border-2 border-yellow-400 p-4 text-sm">
                   <h4 className="font-bold flex items-center gap-2 mb-2"><Key size={16}/> PASSWORD MANAGEMENT</h4>
                   <p className="mb-2">To change your password, you must verify your identity via OTP sent to your registered email: <strong>omipawar17@gmail.com</strong>.</p>
                </div>

                {resetStep === 'request' ? (
                  <button 
                    onClick={handleSendOtp}
                    className="w-full bg-black text-white p-4 font-bold uppercase hover:bg-deep-purple transition-all border-2 border-transparent hover:border-black"
                  >
                    Initiate Password Change
                  </button>
                ) : (
                  <div className="space-y-4 bg-gray-50 p-4 border-2 border-black">
                     <h4 className="font-black uppercase text-sm">Verify Identity</h4>
                     <input 
                        type="text"
                        value={otpInput}
                        onChange={(e) => setOtpInput(e.target.value)}
                        className="w-full border-2 border-black p-2 font-mono"
                        placeholder="Enter OTP sent to email"
                      />
                      <input 
                        type="password"
                        value={newPasswordInput}
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        className="w-full border-2 border-black p-2 font-mono"
                        placeholder="New Password"
                      />
                      {resetError && <p className="text-red-600 text-xs font-bold">{resetError}</p>}
                      <div className="flex gap-2">
                        <button onClick={() => setResetStep('request')} className="flex-1 py-2 border-2 border-black font-bold hover:bg-gray-200">Cancel</button>
                        <button onClick={handleVerifyAndReset} className="flex-1 py-2 bg-black text-white font-bold hover:bg-acid-green hover:text-black border-2 border-black">Update Password</button>
                      </div>
                  </div>
                )}
             </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t-4 border-black bg-white sticky bottom-0">
          <button 
            onClick={handleSave}
            className="w-full bg-black text-white py-4 font-black text-xl hover:bg-hot-pink hover:text-white border-2 border-transparent hover:border-black transition-colors flex items-center justify-center gap-2 shadow-hard-sm active:shadow-none active:translate-y-1"
          >
            <Save size={20} /> SAVE CHANGES
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;