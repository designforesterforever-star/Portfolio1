import React from 'react';
import { ArrowUpRight, Figma } from 'lucide-react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <div className={`group relative flex flex-col border-4 border-black bg-white transition-all duration-300 hover:-translate-y-2 hover:shadow-hard-hover shadow-hard overflow-hidden`}>
      <div className={`h-64 w-full border-b-4 border-black overflow-hidden ${project.bgColor}`}>
        <img
          src={project.imageUrl}
          alt={project.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110 group-hover:rotate-1 grayscale group-hover:grayscale-0"
        />
      </div>
      
      <div className="p-6 flex flex-col flex-grow justify-between bg-white relative z-10">
        <div>
          <span className="inline-block px-3 py-1 mb-3 text-xs font-bold border-2 border-black bg-off-white uppercase tracking-wider">
            {project.category}
          </span>
          <h3 className="text-2xl font-black mb-2 leading-tight">{project.title}</h3>
          <p className="text-gray-600 font-mono text-sm leading-relaxed mb-4">
            {project.description}
          </p>
        </div>
        
        <div className="mt-auto flex flex-wrap gap-4 pt-4 border-t-2 border-dashed border-gray-200">
          <a
            href={project.link}
            className="inline-flex items-center gap-2 font-bold hover:text-deep-purple hover:underline decoration-4 underline-offset-2 transition-all"
          >
            View Case Study <ArrowUpRight size={20} />
          </a>
          
          {project.figmaLink && (
             <a
              href={project.figmaLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 font-bold hover:text-hot-pink hover:underline decoration-4 underline-offset-2 transition-all"
            >
              <Figma size={20} /> Figma File
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;