import React, { useState } from 'react';
import { Sparkles, Send, RefreshCw } from 'lucide-react';
import { askTheMuse, generateCreativePrompt } from '../services/geminiService';

const MuseBot: React.FC = () => {
  const [prompt, setPrompt] = useState<string>("");
  const [response, setResponse] = useState<string>("Ask me anything. I'm a 'Senior' AI Designer.");
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'chat' | 'challenge'>('chat');

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsLoading(true);
    const answer = await askTheMuse(prompt);
    setResponse(answer);
    setPrompt("");
    setIsLoading(false);
  };

  const handleGenerateChallenge = async () => {
    setMode('challenge');
    setIsLoading(true);
    const challenge = await generateCreativePrompt();
    setResponse(challenge);
    setIsLoading(false);
  };

  return (
    <section id="muse" className="py-20 px-4 bg-deep-purple border-y-4 border-black">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white border-4 border-black shadow-hard p-8 relative">
            
          {/* Decorative Elements */}
          <div className="absolute -top-6 -right-6 bg-acid-green border-4 border-black p-2 rotate-12 shadow-hard-sm">
            <Sparkles size={32} className="text-black" />
          </div>

          <h2 className="text-4xl font-black mb-2">The AI Muse</h2>
          <p className="font-mono text-sm mb-8 text-gray-600">Powered by Gemini 2.5 Flash. It's fast and slightly judgmental.</p>

          <div className="min-h-[120px] bg-off-white border-2 border-black p-6 mb-6 flex items-center justify-center text-center">
            {isLoading ? (
              <div className="flex gap-2 animate-pulse">
                 <div className="w-4 h-4 bg-black rounded-full animate-bounce"></div>
                 <div className="w-4 h-4 bg-black rounded-full animate-bounce delay-100"></div>
                 <div className="w-4 h-4 bg-black rounded-full animate-bounce delay-200"></div>
              </div>
            ) : (
              <p className={`text-xl font-bold ${mode === 'challenge' ? 'text-hot-pink' : 'text-black'}`}>
                "{response}"
              </p>
            )}
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <form onSubmit={handleAsk} className="flex-grow flex gap-2">
              <input
                type="text"
                value={prompt}
                onChange={(e) => { setMode('chat'); setPrompt(e.target.value); }}
                placeholder="Ask for design wisdom..."
                className="flex-grow border-2 border-black p-3 font-mono focus:outline-none focus:bg-yellow-100 transition-colors"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="bg-black text-white p-3 border-2 border-black hover:bg-acid-green hover:text-black transition-colors disabled:opacity-50"
              >
                <Send size={20} />
              </button>
            </form>
            
            <div className="flex items-center justify-center text-xs font-bold uppercase tracking-widest mx-2">OR</div>

            <button
              onClick={handleGenerateChallenge}
              disabled={isLoading}
              className="bg-hot-pink text-white p-3 px-6 border-2 border-black hover:bg-white hover:text-black transition-colors font-bold flex items-center gap-2 justify-center shadow-hard-sm active:translate-y-1 active:shadow-none"
            >
              <RefreshCw size={18} className={isLoading ? "animate-spin" : ""} />
              Chaos Mode
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MuseBot;