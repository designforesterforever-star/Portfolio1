import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateCreativePrompt = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: 'Generate a short, bizarre, and funny design constraint or challenge for a UI designer. Maximum 20 words. Keep it quirky.',
      config: {
        temperature: 1.2, // High creativity
      }
    });
    return response.text || "Design a button that runs away from the cursor.";
  } catch (error) {
    console.error("Error generating prompt:", error);
    return "Make it pop (literally).";
  }
};

export const askTheMuse = async (question: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are a pretentious but lovable art director named "Pixel". Answer this design question with a mix of deep wisdom and absolute nonsense. Keep it under 40 words. Question: ${question}`,
    });
    return response.text || "It needs more white space. Or less. Definitely one of those.";
  } catch (error) {
    console.error("Error asking muse:", error);
    return "The creative energies are blocked right now. Try again later.";
  }
};